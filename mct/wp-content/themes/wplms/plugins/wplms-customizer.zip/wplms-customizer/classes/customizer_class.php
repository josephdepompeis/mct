<?php

if(!class_exists('WPLMS_Customizer_Plugin_Class')){

class WPLMS_Customizer_Plugin_Class{
    public function __construct(){


    } // END public function __construct



    } // END class WPLMS_Customizer_Class
} // END if(!class_exists('WPLMS_Customizer_Class'))

?>
